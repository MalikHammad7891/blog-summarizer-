# BlogSummarize AI

A premium blog summarizer application powered by AI that converts any blog post into intelligent summaries in English.

## Features

- 🤖 **AI-Powered Summarization** - Uses OpenAI GPT-4o for intelligent blog summarization
- 🔐 **Secure Authentication** - User login/logout with session management
- 💳 **Payment Plans** - Free (5 summaries/month) and Pro (100 summaries/month) tiers
- 📊 **Smart History** - Save, search, and manage your summary collection
- 🎨 **Modern UI** - Beautiful responsive design with gradient themes
- 🌐 **Universal Support** - Works with any blog platform (Medium, WordPress, etc.)

## Tech Stack

- **Frontend**: React + TypeScript + Vite
- **Backend**: Express.js + Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **AI**: OpenAI GPT-4o
- **Payments**: Stripe
- **Authentication**: Replit Auth (OIDC)
- **UI**: shadcn/ui + Tailwind CSS

## Quick Start

1. Clone the repository
2. Install dependencies: `npm install`
3. Set up environment variables (see below)
4. Run database migrations: `npm run db:push`
5. Start development server: `npm run dev`

## Environment Variables

Create a `.env` file with:

```env
DATABASE_URL=your_postgresql_url
OPENAI_API_KEY=sk-your_openai_key
STRIPE_SECRET_KEY=sk_test_your_stripe_secret
VITE_STRIPE_PUBLIC_KEY=pk_test_your_stripe_public
SESSION_SECRET=your_session_secret
REPL_ID=your_repl_id
```

## Deployment to Vercel

1. Push your code to GitHub
2. Connect your GitHub repo to Vercel
3. Add environment variables in Vercel dashboard
4. Deploy automatically

## Usage

1. Enter any blog URL
2. Get AI-powered summary in seconds
3. Save to your personal history
4. Search and manage your summaries
5. Upgrade to Pro for unlimited summaries

## License

MIT License