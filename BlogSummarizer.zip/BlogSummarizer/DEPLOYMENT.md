# Deploy BlogSummarize AI to Vercel

Follow these simple steps to deploy your blog summarizer app and get a live URL:

## Step 1: Download Your Project

1. **Download from Replit**: 
   - Click the three dots menu in Replit
   - Select "Download as ZIP"
   - Extract the ZIP file to your computer

## Step 2: Upload to GitHub

1. **Create GitHub Account**: Go to [github.com](https://github.com) and sign up (if you don't have one)

2. **Create New Repository**:
   - Click "New repository" button
   - Name it: `blog-summarizer-ai`
   - Make it Public
   - Don't initialize with README (we already have one)
   - Click "Create repository"

3. **Upload Your Code**:
   - Click "uploading an existing file"
   - Drag and drop all your project files
   - Write commit message: "Initial commit - BlogSummarize AI"
   - Click "Commit changes"

## Step 3: Deploy to Vercel

1. **Create Vercel Account**: Go to [vercel.com](https://vercel.com) and sign up with GitHub

2. **Import Your Project**:
   - Click "New Project"
   - Select your `blog-summarizer-ai` repository
   - Click "Import"

3. **Configure Build Settings**:
   - Framework Preset: **Other**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

4. **Add Environment Variables**:
   In Vercel dashboard, go to Settings > Environment Variables and add:
   ```
   DATABASE_URL = your_postgresql_url
   OPENAI_API_KEY = your_openai_key
   STRIPE_SECRET_KEY = your_stripe_secret_key
   VITE_STRIPE_PUBLIC_KEY = your_stripe_public_key
   SESSION_SECRET = any_random_string
   REPL_ID = your_repl_id
   ```

5. **Deploy**:
   - Click "Deploy"
   - Wait for build to complete
   - Get your live URL: `https://your-app-name.vercel.app`

## Step 4: Update Database (Important!)

Since you're using a new deployment, you'll need to run the database setup:

1. In Vercel dashboard, go to Functions tab
2. Or use Vercel CLI: `npx drizzle-kit push`

## Your Live URL

After deployment, you'll get a URL like:
`https://blog-summarizer-ai-username.vercel.app`

Share this URL with anyone to use your blog summarizer!

## Troubleshooting

- **Build fails**: Check environment variables are set correctly
- **Database errors**: Make sure DATABASE_URL is correct
- **API errors**: Verify OpenAI and Stripe keys are valid
- **Auth issues**: Ensure REPL_ID and SESSION_SECRET are set

## Automatic Updates

Every time you push new code to GitHub, Vercel will automatically redeploy your app with the latest changes!