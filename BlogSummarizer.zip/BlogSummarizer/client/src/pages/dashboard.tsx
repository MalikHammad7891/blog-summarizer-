import { useEffect, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Badge } from "@/components/ui/badge";
import { 
  Download, 
  Brain, 
  Zap, 
  Calendar, 
  Clock, 
  Crown, 
  Search, 
  Eye, 
  Share, 
  Trash2,
  ExternalLink,
  Plus
} from "lucide-react";
import Navbar from "@/components/navbar";
import SummaryModal from "@/components/summary-modal";
import type { Summary, User } from "@shared/schema";

export default function Dashboard() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSummary, setSelectedSummary] = useState<Summary | null>(null);
  const [urlInput, setUrlInput] = useState("");

  // Redirect if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, authLoading, toast]);

  // Fetch summaries
  const { data: summaries = [], isLoading: summariesLoading } = useQuery({
    queryKey: ["/api/summaries"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Fetch stats
  const { data: stats } = useQuery({
    queryKey: ["/api/stats"],
    enabled: isAuthenticated,
    retry: false,
  });

  // Create new summary mutation
  const createSummaryMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await apiRequest("POST", "/api/summarize", { url });
      return response.json();
    },
    onSuccess: (newSummary: Summary) => {
      queryClient.invalidateQueries({ queryKey: ["/api/summaries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      setSelectedSummary(newSummary);
      setUrlInput("");
      toast({
        title: "Summary Generated!",
        description: "Your blog summary is ready to view.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      
      let message = "Failed to generate summary. Please try again.";
      if (error.message.includes("403") || error.message.includes("LIMIT_REACHED")) {
        message = "Monthly limit reached. Please upgrade to Pro for unlimited summaries.";
      } else if (error.message.includes("400")) {
        message = "Unable to access the provided URL. Please check if it's valid and accessible.";
      }
      
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    },
  });

  // Delete summary mutation
  const deleteSummaryMutation = useMutation({
    mutationFn: async (summaryId: number) => {
      await apiRequest("DELETE", `/api/summaries/${summaryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/summaries"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Summary deleted",
        description: "The summary has been removed from your history.",
      });
    },
    onError: (error: any) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to delete summary. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleCreateSummary = () => {
    if (!urlInput.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a valid blog URL",
        variant: "destructive",
      });
      return;
    }

    try {
      new URL(urlInput);
      createSummaryMutation.mutate(urlInput);
    } catch {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL starting with http:// or https://",
        variant: "destructive",
      });
    }
  };

  const handleDeleteSummary = (summaryId: number) => {
    if (confirm("Are you sure you want to delete this summary?")) {
      deleteSummaryMutation.mutate(summaryId);
    }
  };

  const filteredSummaries = summaries.filter((summary: Summary) =>
    summary.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    summary.url.toLowerCase().includes(searchTerm.toLowerCase()) ||
    summary.category?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Will redirect in useEffect
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Your Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage your blog summaries and track your reading efficiency</p>
          </div>
        </div>

        {/* Quick Summarize */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Plus className="mr-2 w-5 h-5" />
              Create New Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex space-x-4">
              <Input
                placeholder="Enter blog URL to summarize..."
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                disabled={createSummaryMutation.isPending}
                className="flex-1"
              />
              <Button 
                onClick={handleCreateSummary}
                disabled={createSummaryMutation.isPending}
                className="gradient-primary text-white"
              >
                {createSummaryMutation.isPending ? (
                  <>
                    <LoadingSpinner size="sm" className="mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 w-4 h-4" />
                    Summarize
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="gradient-primary text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-blue-100">Total Summaries</p>
                  <p className="text-3xl font-bold">{stats?.totalSummaries || 0}</p>
                </div>
                <Brain className="w-8 h-8 text-blue-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-green-100">This Month</p>
                  <p className="text-3xl font-bold">{stats?.thisMonth || 0}</p>
                </div>
                <Calendar className="w-8 h-8 text-green-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-purple-100">Time Saved</p>
                  <p className="text-3xl font-bold">{stats?.timeSaved || 0}h</p>
                </div>
                <Clock className="w-8 h-8 text-purple-200" />
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-orange-100">Plan</p>
                  <p className="text-xl font-bold capitalize">{user?.plan || 'Free'}</p>
                </div>
                <Crown className="w-8 h-8 text-orange-200" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Summaries */}
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Recent Summaries</CardTitle>
              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search summaries..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {summariesLoading ? (
              <div className="flex items-center justify-center py-8">
                <LoadingSpinner size="lg" />
              </div>
            ) : filteredSummaries.length === 0 ? (
              <div className="text-center py-8">
                <Brain className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  {searchTerm ? "No summaries found" : "No summaries yet"}
                </h3>
                <p className="text-gray-600">
                  {searchTerm 
                    ? "Try adjusting your search terms"
                    : "Create your first summary by entering a blog URL above"
                  }
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredSummaries.map((summary: Summary) => (
                  <div key={summary.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900 mb-1">{summary.title}</h4>
                        <p className="text-sm text-gray-600 mb-2 truncate">{summary.url}</p>
                        <p className="text-sm text-gray-700 line-clamp-2 mb-2">
                          {summary.summary.substring(0, 200)}...
                        </p>
                        <div className="flex items-center space-x-4">
                          <span className="text-xs text-gray-500">
                            {new Date(summary.createdAt || '').toLocaleDateString()}
                          </span>
                          {summary.readTime && (
                            <span className="text-xs text-gray-500">{summary.readTime} min read</span>
                          )}
                          {summary.category && (
                            <Badge variant="secondary" className="text-xs">
                              {summary.category}
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-4">
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => setSelectedSummary(summary)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => window.open(summary.url, '_blank')}
                        >
                          <ExternalLink className="w-4 h-4" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm"
                          onClick={() => handleDeleteSummary(summary.id)}
                          disabled={deleteSummaryMutation.isPending}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <SummaryModal 
        isOpen={!!selectedSummary}
        onClose={() => setSelectedSummary(null)}
        summary={selectedSummary}
      />
    </div>
  );
}
