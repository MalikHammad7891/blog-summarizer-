import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Brain, Zap, History, Globe, Languages, Shield, Smartphone, TrendingUp, Check, X } from "lucide-react";
import Navbar from "@/components/navbar";
import SummaryModal from "@/components/summary-modal";
import type { Summary } from "@shared/schema";

export default function Landing() {
  const [url, setUrl] = useState("");
  const [selectedSummary, setSelectedSummary] = useState<Summary | null>(null);
  const { toast } = useToast();

  const summarizeMutation = useMutation({
    mutationFn: async (blogUrl: string) => {
      const response = await apiRequest("POST", "/api/summarize", { url: blogUrl });
      return response.json();
    },
    onSuccess: (summary: Summary) => {
      setSelectedSummary(summary);
      setUrl("");
      toast({
        title: "Summary Generated!",
        description: "Your blog summary is ready to view.",
      });
    },
    onError: (error: any) => {
      let message = "Failed to generate summary. Please try again.";
      
      if (error.message.includes("401")) {
        message = "Please log in to summarize blogs.";
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 2000);
      } else if (error.message.includes("403") || error.message.includes("LIMIT_REACHED")) {
        message = "Monthly limit reached. Please upgrade to Pro for unlimited summaries.";
      } else if (error.message.includes("400")) {
        message = "Unable to access the provided URL. Please check if it's valid and accessible.";
      }
      
      toast({
        title: "Error",
        description: message,
        variant: "destructive",
      });
    },
  });

  const handleSummarize = () => {
    if (!url.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a valid blog URL",
        variant: "destructive",
      });
      return;
    }

    try {
      new URL(url);
      summarizeMutation.mutate(url);
    } catch {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid URL starting with http:// or https://",
        variant: "destructive",
      });
    }
  };

  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              Transform Long Blogs into{" "}
              <span className="text-gradient">Smart Summaries</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
              Powered by advanced AI, BlogSummarize instantly converts any blog post into clear, 
              concise summaries in English. Save time and stay informed with intelligent content processing.
            </p>
            
            {/* URL Input Section */}
            <div className="max-w-2xl mx-auto">
              <Card className="shadow-xl border-0">
                <CardContent className="p-8">
                  <div className="mb-6">
                    <label htmlFor="blogUrl" className="block text-sm font-medium text-gray-700 mb-2">
                      Enter Blog URL
                    </label>
                    <div className="relative">
                      <Input 
                        type="url" 
                        id="blogUrl" 
                        value={url}
                        onChange={(e) => setUrl(e.target.value)}
                        placeholder="https://example.com/blog-post" 
                        className="pr-10"
                        disabled={summarizeMutation.isPending}
                      />
                      <div className="absolute inset-y-0 right-0 flex items-center pr-3">
                        <Globe className="text-gray-400 w-4 h-4" />
                      </div>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={handleSummarize}
                    disabled={summarizeMutation.isPending}
                    className="w-full gradient-primary text-white hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
                  >
                    {summarizeMutation.isPending ? (
                      <>
                        <LoadingSpinner size="sm" className="mr-2" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Brain className="mr-2 w-4 h-4" />
                        Summarize with AI
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>
            </div>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Zap className="text-primary w-6 h-6" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Lightning Fast</h3>
                <p className="text-gray-600">Get summaries in seconds, not minutes</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <Brain className="text-secondary w-6 h-6" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">AI Powered</h3>
                <p className="text-gray-600">Advanced language models ensure accuracy</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                  <History className="text-accent w-6 h-6" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Smart History</h3>
                <p className="text-gray-600">Save and organize your summaries</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Powerful Features for Every User</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Everything you need to efficiently process and manage blog content with intelligent AI assistance.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-6">
                  <Globe className="text-blue-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Universal URL Support</h3>
                <p className="text-gray-600">
                  Works with any blog platform - Medium, WordPress, Substack, and more. 
                  Just paste the URL and let AI do the work.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-6">
                  <Languages className="text-green-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">English Summaries</h3>
                <p className="text-gray-600">
                  No matter the source language, get clear, well-structured summaries 
                  in perfect English every time.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-6">
                  <History className="text-purple-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Smart History</h3>
                <p className="text-gray-600">
                  Automatically save all summaries with searchable tags. 
                  Access your reading history anytime, anywhere.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-6">
                  <Shield className="text-red-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Secure & Private</h3>
                <p className="text-gray-600">
                  Your data is encrypted and secure. We respect your privacy 
                  and never share your reading history.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-6">
                  <Smartphone className="text-yellow-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Mobile Ready</h3>
                <p className="text-gray-600">
                  Perfect experience on desktop, tablet, and mobile. 
                  Summarize content on the go with our responsive design.
                </p>
              </CardContent>
            </Card>

            <Card className="hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-6">
                  <TrendingUp className="text-indigo-600 w-6 h-6" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Usage Analytics</h3>
                <p className="text-gray-600">
                  Track your reading efficiency with detailed analytics. 
                  See how much time you're saving with AI summaries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-primary/5 to-secondary/5">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">Ready to Save Time?</h2>
          <p className="text-xl text-gray-600 mb-8">
            Join thousands of users who are already saving hours with AI-powered summaries.
          </p>
          <Button onClick={handleLogin} size="lg" className="gradient-primary text-white hover:shadow-lg transform hover:-translate-y-0.5 transition-all">
            Get Started Free
          </Button>
        </div>
      </section>

      <SummaryModal 
        isOpen={!!selectedSummary}
        onClose={() => setSelectedSummary(null)}
        summary={selectedSummary}
      />
    </div>
  );
}
