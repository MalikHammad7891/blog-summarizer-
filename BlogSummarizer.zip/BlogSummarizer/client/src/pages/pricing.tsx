import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, X, Crown } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useEffect } from "react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import Navbar from "@/components/navbar";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const SubscribeForm = ({ onSuccess }: { onSuccess: () => void }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    setIsProcessing(false);

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "You are now subscribed to Pro!",
      });
      onSuccess();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing}
        className="w-full gradient-primary text-white"
      >
        {isProcessing ? (
          <>
            <LoadingSpinner size="sm" className="mr-2" />
            Processing...
          </>
        ) : (
          <>
            <Crown className="mr-2 w-4 h-4" />
            Subscribe to Pro
          </>
        )}
      </Button>
    </form>
  );
};

export default function Pricing() {
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [showPayment, setShowPayment] = useState(false);
  const [clientSecret, setClientSecret] = useState("");

  const handleUpgrade = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Login Required",
        description: "Please login to upgrade your plan",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 1500);
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/create-subscription");
      const data = await response.json();
      setClientSecret(data.clientSecret);
      setShowPayment(true);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to initialize payment. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePaymentSuccess = () => {
    setShowPayment(false);
    toast({
      title: "Welcome to Pro!",
      description: "Your account has been upgraded successfully.",
    });
    // Refresh the page to update user data
    setTimeout(() => {
      window.location.reload();
    }, 2000);
  };

  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "/month",
      description: "Perfect for trying out the service",
      features: [
        { text: "5 summaries per month", included: true },
        { text: "Basic history (7 days)", included: true },
        { text: "Standard AI processing", included: true },
        { text: "Advanced analytics", included: false },
        { text: "Export summaries", included: false },
        { text: "Priority support", included: false },
      ],
      current: user?.plan === "free" || !user?.plan,
      buttonText: "Current Plan",
      buttonVariant: "secondary" as const,
    },
    {
      name: "Pro",
      price: "$19",
      period: "/month",
      description: "For regular readers and professionals",
      features: [
        { text: "100 summaries per month", included: true },
        { text: "Unlimited history", included: true },
        { text: "Priority AI processing", included: true },
        { text: "Advanced analytics", included: true },
        { text: "Export summaries", included: true },
        { text: "Priority support", included: true },
      ],
      popular: true,
      current: user?.plan === "pro",
      buttonText: user?.plan === "pro" ? "Current Plan" : "Upgrade to Pro",
      buttonVariant: user?.plan === "pro" ? "secondary" as const : "default" as const,
      onUpgrade: handleUpgrade,
    },
    {
      name: "Enterprise",
      price: "$99",
      period: "/month",
      description: "For teams and heavy users",
      features: [
        { text: "Unlimited summaries", included: true },
        { text: "Team collaboration", included: true },
        { text: "API access", included: true },
        { text: "Custom integrations", included: true },
        { text: "Advanced analytics", included: true },
        { text: "Dedicated support", included: true },
      ],
      current: user?.plan === "enterprise",
      buttonText: "Contact Sales",
      buttonVariant: "secondary" as const,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Start free and upgrade as you need more summaries and advanced features.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan) => (
              <Card 
                key={plan.name} 
                className={`relative hover:shadow-lg transition-shadow ${
                  plan.popular ? 'border-2 border-primary' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="gradient-primary text-white px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl font-bold text-gray-900 mb-2">
                    {plan.name}
                  </CardTitle>
                  <div className="text-4xl font-bold text-gray-900 mb-2">
                    {plan.price}
                    <span className="text-lg text-gray-600 font-normal">{plan.period}</span>
                  </div>
                  <p className="text-gray-600">{plan.description}</p>
                </CardHeader>
                
                <CardContent>
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        {feature.included ? (
                          <Check className="text-green-500 mr-3 w-4 h-4" />
                        ) : (
                          <X className="text-gray-400 mr-3 w-4 h-4" />
                        )}
                        <span className={feature.included ? "" : "text-gray-400"}>
                          {feature.text}
                        </span>
                      </li>
                    ))}
                  </ul>
                  
                  <Button 
                    className={`w-full ${
                      plan.popular && !plan.current 
                        ? 'gradient-primary text-white hover:shadow-lg transform hover:-translate-y-0.5 transition-all' 
                        : ''
                    }`}
                    variant={plan.buttonVariant}
                    onClick={plan.onUpgrade}
                    disabled={plan.current}
                  >
                    {plan.current && <Check className="mr-2 w-4 h-4" />}
                    {plan.buttonText}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* FAQ Section */}
          <div className="mt-20 max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Frequently Asked Questions
            </h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Can I change my plan anytime?
                </h3>
                <p className="text-gray-600">
                  Yes, you can upgrade or downgrade your plan at any time. Changes will be reflected in your next billing cycle.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  What happens to my summaries if I downgrade?
                </h3>
                <p className="text-gray-600">
                  Your existing summaries will be preserved, but you'll be limited to the new plan's monthly allowance going forward.
                </p>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  Is there a free trial for Pro?
                </h3>
                <p className="text-gray-600">
                  The Free plan serves as a trial with 5 summaries per month. You can upgrade to Pro anytime for unlimited access.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Modal */}
      <Dialog open={showPayment} onOpenChange={setShowPayment}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Upgrade to Pro</DialogTitle>
          </DialogHeader>
          
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex justify-between items-center">
              <span className="font-medium">Pro Plan</span>
              <span className="text-xl font-bold">$19/month</span>
            </div>
          </div>
          
          {clientSecret && (
            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <SubscribeForm onSuccess={handlePaymentSuccess} />
            </Elements>
          )}
          
          <div className="text-center text-sm text-gray-500 mt-4">
            <Crown className="w-4 h-4 inline mr-1" />
            Payments secured by Stripe
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
