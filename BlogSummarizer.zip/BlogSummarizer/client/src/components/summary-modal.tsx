import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Copy, Save, Clock, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Summary } from "@shared/schema";

interface SummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
  summary: Summary | null;
}

export default function SummaryModal({ isOpen, onClose, summary }: SummaryModalProps) {
  const { toast } = useToast();

  const handleCopy = async () => {
    if (!summary) return;
    
    try {
      await navigator.clipboard.writeText(summary.summary);
      toast({
        title: "Copied!",
        description: "Summary copied to clipboard",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleShare = () => {
    if (!summary) return;
    
    const shareData = {
      title: summary.title,
      text: summary.summary,
      url: summary.url,
    };

    if (navigator.share) {
      navigator.share(shareData);
    } else {
      // Fallback to copy URL
      navigator.clipboard.writeText(summary.url);
      toast({
        title: "URL copied",
        description: "Blog URL copied to clipboard",
      });
    }
  };

  if (!summary) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
            {summary.title}
          </DialogTitle>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <a 
              href={summary.url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-1 hover:text-primary transition-colors"
            >
              <ExternalLink className="w-4 h-4" />
              <span>View Original</span>
            </a>
            {summary.readTime && (
              <div className="flex items-center space-x-1">
                <Clock className="w-4 h-4" />
                <span>{summary.readTime} min read</span>
              </div>
            )}
            {summary.category && (
              <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                {summary.category}
              </span>
            )}
          </div>
        </DialogHeader>
        
        <div className="bg-gray-50 rounded-lg p-6 my-6">
          <h3 className="font-semibold text-gray-900 mb-3">AI Summary</h3>
          <div className="prose prose-gray max-w-none">
            {summary.summary.split('\n').map((paragraph, index) => (
              <p key={index} className="mb-4 text-gray-700 leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
        
        <div className="flex justify-between items-center pt-4 border-t">
          <div className="text-sm text-gray-500">
            Summary generated on {new Date(summary.createdAt || '').toLocaleDateString()}
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleCopy}>
              <Copy className="w-4 h-4 mr-2" />
              Copy
            </Button>
            <Button variant="outline" onClick={handleShare}>
              <ExternalLink className="w-4 h-4 mr-2" />
              Share
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
