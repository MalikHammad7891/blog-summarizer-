#!/bin/bash

# Install dependencies
npm install

# Build client
cd client
npm run build
cd ..

# Copy client build to dist
mkdir -p dist
cp -r client/dist/* dist/

# Build server
npm run build:server