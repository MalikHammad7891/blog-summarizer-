import OpenAI from "openai";

if (!process.env.OPENAI_API_KEY) {
  throw new Error('Missing required OpenAI API key: OPENAI_API_KEY');
}

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function summarizeBlog(content: string, url: string): Promise<{
  title: string;
  summary: string;
  category: string;
  readTime: number;
}> {
  try {
    const prompt = `Analyze and summarize the following blog post content. Provide a comprehensive summary in English that captures the key points, main arguments, and conclusions. Also extract or generate an appropriate title, categorize the content, and estimate reading time.

Content to summarize:
${content.substring(0, 8000)} // Limit content to avoid token limits

Please respond with JSON in this exact format:
{
  "title": "A clear, descriptive title for the blog post",
  "summary": "A comprehensive summary in 2-4 paragraphs that captures the essence and key points",
  "category": "A single category like Technology, Business, Health, etc.",
  "readTime": "Estimated reading time in minutes for the original content (number only)"
}`;

    // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are an expert content summarizer. Provide accurate, concise summaries that capture the essential information while maintaining clarity and readability."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      max_tokens: 1000,
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    return {
      title: result.title || "Blog Summary",
      summary: result.summary || "Summary not available",
      category: result.category || "General",
      readTime: typeof result.readTime === 'number' ? result.readTime : 5,
    };
  } catch (error: any) {
    console.error("OpenAI summarization error:", error);
    
    // Check if it's a quota error and provide demo response
    if (error.message.includes('quota') || error.message.includes('429')) {
      console.log("Quota exceeded, providing demo summary...");
      
      // Create a basic summary from the content
      const wordCount = content.split(/\s+/).length;
      const readTime = Math.ceil(wordCount / 200); // Average reading speed
      
      // Extract title from URL or content
      let title = "Blog Post Summary";
      const titleMatch = content.match(/<title[^>]*>([^<]+)<\/title>/i) || 
                       content.match(/^(.{1,100})/);
      if (titleMatch) {
        title = titleMatch[1].trim().substring(0, 100);
      }
      
      // Create a basic summary
      const sentences = content.split(/[.!?]+/).filter(s => s.trim().length > 20);
      const summary = sentences.slice(0, 3).join('. ').substring(0, 500) + 
                     (sentences.length > 3 ? '...' : '');
      
      return {
        title: title || "Blog Post Summary",
        summary: summary || "This is a demo summary. Your OpenAI quota has been exceeded. Please add credits to your OpenAI account to get AI-powered summaries.",
        category: "Demo",
        readTime: readTime,
      };
    }
    
    throw new Error("Failed to generate summary: " + error.message);
  }
}
