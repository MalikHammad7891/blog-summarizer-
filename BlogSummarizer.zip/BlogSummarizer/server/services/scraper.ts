import { JSDOM } from "jsdom";

export async function scrapeBlogContent(url: string): Promise<{
  content: string;
  wordCount: number;
}> {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to fetch content: ${response.status} ${response.statusText}`);
    }

    const html = await response.text();
    const dom = new JSDOM(html);
    const document = dom.window.document;

    // Remove script and style elements
    const scripts = document.querySelectorAll('script, style, nav, header, footer, aside');
    scripts.forEach(el => el.remove());

    // Try to find main content area
    let content = '';
    
    // Common selectors for blog content
    const contentSelectors = [
      'article',
      '[role="main"]',
      '.post-content',
      '.entry-content',
      '.content',
      '.post-body',
      '.story-body',
      'main',
      '.article-body'
    ];

    for (const selector of contentSelectors) {
      const element = document.querySelector(selector);
      if (element) {
        content = element.textContent || '';
        break;
      }
    }

    // Fallback to body content if no specific content area found
    if (!content) {
      content = document.body.textContent || '';
    }

    // Clean up the content
    content = content
      .replace(/\s+/g, ' ') // Replace multiple whitespace with single space
      .replace(/\n\s*\n/g, '\n') // Remove empty lines
      .trim();

    if (!content || content.length < 100) {
      throw new Error('Unable to extract meaningful content from the URL');
    }

    const wordCount = content.split(/\s+/).length;

    return {
      content,
      wordCount
    };
  } catch (error: any) {
    console.error("Scraping error:", error);
    throw new Error(`Failed to scrape content: ${error.message}`);
  }
}
