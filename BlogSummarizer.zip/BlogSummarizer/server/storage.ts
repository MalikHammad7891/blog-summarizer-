import {
  users,
  summaries,
  type User,
  type UpsertUser,
  type Summary,
  type InsertSummary,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User>;
  
  // Summary operations
  createSummary(summary: InsertSummary): Promise<Summary>;
  getUserSummaries(userId: string, limit?: number): Promise<Summary[]>;
  deleteSummary(id: number, userId: string): Promise<boolean>;
  getSummary(id: number, userId: string): Promise<Summary | undefined>;
  getUserSummaryStats(userId: string): Promise<{
    totalSummaries: number;
    thisMonth: number;
    timeSaved: number; // in hours
  }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  // (IMPORTANT) these user operations are mandatory for Replit Auth.

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async updateUserStripeInfo(userId: string, stripeCustomerId: string, stripeSubscriptionId: string): Promise<User> {
    const [user] = await db
      .update(users)
      .set({
        stripeCustomerId,
        stripeSubscriptionId,
        plan: "pro",
        updatedAt: new Date(),
      })
      .where(eq(users.id, userId))
      .returning();
    return user;
  }

  // Summary operations
  async createSummary(summary: InsertSummary): Promise<Summary> {
    const [newSummary] = await db
      .insert(summaries)
      .values(summary)
      .returning();
    return newSummary;
  }

  async getUserSummaries(userId: string, limit = 50): Promise<Summary[]> {
    return await db
      .select()
      .from(summaries)
      .where(eq(summaries.userId, userId))
      .orderBy(desc(summaries.createdAt))
      .limit(limit);
  }

  async deleteSummary(id: number, userId: string): Promise<boolean> {
    const result = await db
      .delete(summaries)
      .where(and(eq(summaries.id, id), eq(summaries.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  async getSummary(id: number, userId: string): Promise<Summary | undefined> {
    const [summary] = await db
      .select()
      .from(summaries)
      .where(and(eq(summaries.id, id), eq(summaries.userId, userId)));
    return summary;
  }

  async getUserSummaryStats(userId: string): Promise<{
    totalSummaries: number;
    thisMonth: number;
    timeSaved: number;
  }> {
    const allSummaries = await db
      .select()
      .from(summaries)
      .where(eq(summaries.userId, userId));

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const thisMonthSummaries = allSummaries.filter(
      s => s.createdAt && s.createdAt >= startOfMonth
    );

    const totalReadTime = allSummaries.reduce((sum, s) => sum + (s.readTime || 0), 0);
    const timeSaved = Math.round((totalReadTime * 0.8) / 60); // Assuming 80% time saved, convert to hours

    return {
      totalSummaries: allSummaries.length,
      thisMonth: thisMonthSummaries.length,
      timeSaved,
    };
  }
}

export const storage = new DatabaseStorage();
