import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { summarizeBlog } from "./services/openai";
import { scrapeBlogContent } from "./services/scraper";
import { urlInputSchema, insertSummarySchema } from "@shared/schema";
import { z } from "zod";
import Stripe from "stripe";

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('Missing required Stripe secret: STRIPE_SECRET_KEY');
}

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-06-30.basil",
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Blog summarization endpoint
  app.post('/api/summarize', isAuthenticated, async (req: any, res) => {
    try {
      const { url } = urlInputSchema.parse(req.body);
      const userId = req.user.claims.sub;
      
      // Check user's plan and usage limits
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const stats = await storage.getUserSummaryStats(userId);
      
      // Enforce plan limits
      if (user.plan === "free" && stats.thisMonth >= 5) {
        return res.status(403).json({ 
          message: "Monthly limit reached. Please upgrade to Pro for unlimited summaries.",
          code: "LIMIT_REACHED"
        });
      }

      // Scrape blog content
      const blogContent = await scrapeBlogContent(url);
      
      // Generate AI summary
      const summaryData = await summarizeBlog(blogContent.content, url);
      
      // Save to database
      const summary = await storage.createSummary({
        userId,
        title: summaryData.title,
        url,
        originalContent: blogContent.content,
        summary: summaryData.summary,
        category: summaryData.category,
        readTime: summaryData.readTime,
        wordCount: blogContent.wordCount,
      });

      res.json(summary);
    } catch (error: any) {
      console.error("Summarization error:", error);
      if (error.message.includes("Invalid URL") || error.message.includes("Failed to fetch")) {
        res.status(400).json({ message: "Unable to access the provided URL. Please check if it's valid and accessible." });
      } else {
        res.status(500).json({ message: "Failed to generate summary. Please try again." });
      }
    }
  });

  // Get user summaries
  app.get('/api/summaries', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const summaries = await storage.getUserSummaries(userId);
      res.json(summaries);
    } catch (error) {
      console.error("Error fetching summaries:", error);
      res.status(500).json({ message: "Failed to fetch summaries" });
    }
  });

  // Get user stats
  app.get('/api/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getUserSummaryStats(userId);
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Delete summary
  app.delete('/api/summaries/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const summaryId = parseInt(req.params.id);
      
      const deleted = await storage.deleteSummary(summaryId, userId);
      if (!deleted) {
        return res.status(404).json({ message: "Summary not found" });
      }
      
      res.json({ message: "Summary deleted successfully" });
    } catch (error) {
      console.error("Error deleting summary:", error);
      res.status(500).json({ message: "Failed to delete summary" });
    }
  });

  // Stripe subscription endpoint
  app.post('/api/create-subscription', isAuthenticated, async (req: any, res) => {
    const userId = req.user.claims.sub;
    const user = await storage.getUser(userId);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    if (user.stripeSubscriptionId) {
      const subscription = await stripe.subscriptions.retrieve(user.stripeSubscriptionId);
      const invoice = typeof subscription.latest_invoice === 'object' ? subscription.latest_invoice : null;
      const paymentIntent = invoice && typeof (invoice as any).payment_intent === 'object' ? (invoice as any).payment_intent : null;
      
      res.send({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent?.client_secret,
      });
      return;
    }
    
    if (!user.email) {
      return res.status(400).json({ message: 'No user email on file' });
    }

    try {
      const customer = await stripe.customers.create({
        email: user.email,
        name: `${user.firstName || ''} ${user.lastName || ''}`.trim(),
      });

      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price: process.env.STRIPE_PRICE_ID || 'price_1234567890', // Replace with actual price ID
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      });

      await storage.updateUserStripeInfo(userId, customer.id, subscription.id);
  
      const invoice = typeof subscription.latest_invoice === 'object' ? subscription.latest_invoice : null;
      const paymentIntent = invoice && typeof (invoice as any).payment_intent === 'object' ? (invoice as any).payment_intent : null;
      
      res.send({
        subscriptionId: subscription.id,
        clientSecret: paymentIntent?.client_secret,
      });
    } catch (error: any) {
      console.error("Stripe error:", error);
      return res.status(400).send({ error: { message: error.message } });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
