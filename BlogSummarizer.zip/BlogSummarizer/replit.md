# BlogSummarize AI - Project Overview

## Overview

This is a full-stack web application that uses AI to summarize blog posts and articles. Users can input URLs of blog posts, and the application will scrape the content, summarize it using OpenAI's GPT models, and provide features like saving summaries, categorization, and subscription management through Stripe.

## User Preferences

Preferred communication style: Simple, everyday language.
Deployment preference: Vercel deployment with GitHub integration for live URL access.

## System Architecture

### Tech Stack
- **Frontend**: React with TypeScript, Vite for bundling
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Replit Auth (OIDC-based)
- **AI**: OpenAI GPT-4o for text summarization
- **Payments**: Stripe for subscription management
- **UI**: shadcn/ui components with Tailwind CSS

### Architectural Pattern
The application follows a monorepo structure with clear separation between client and server code:
- `/client` - React frontend application
- `/server` - Express.js backend API
- `/shared` - Shared TypeScript types and schemas

## Key Components

### Frontend Architecture
- **React Router**: Uses `wouter` for client-side routing
- **State Management**: TanStack Query for server state, React hooks for local state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **API Structure**: RESTful endpoints with Express.js
- **Authentication Middleware**: Replit Auth integration with session management
- **Database Layer**: Drizzle ORM with PostgreSQL (using Neon serverless)
- **External Services**: OpenAI API for summarization, web scraping for content extraction

### Database Schema
- **users**: Stores user profiles, subscription info, and Stripe customer data
- **summaries**: Stores blog summaries with metadata (title, category, reading time)
- **sessions**: Required for Replit Auth session management

## Data Flow

1. **Authentication**: Users authenticate via Replit Auth (OIDC)
2. **URL Input**: Users submit blog URLs through the frontend
3. **Content Scraping**: Server scrapes the blog content using JSDOM
4. **AI Processing**: Content is sent to OpenAI for summarization
5. **Storage**: Summaries are saved to PostgreSQL with user association
6. **Plan Limits**: Free users limited to 5 summaries/month, Pro users unlimited

## External Dependencies

### Required Services
- **Neon Database**: PostgreSQL hosting (@neondatabase/serverless)
- **OpenAI API**: For content summarization (gpt-4o model)
- **Stripe**: Payment processing and subscription management
- **Replit Auth**: Authentication service (OIDC-based)

### Key Libraries
- **UI**: @radix-ui components, @stripe/stripe-js, @stripe/react-stripe-js
- **Data**: drizzle-orm, @tanstack/react-query
- **Validation**: zod for schema validation
- **Utilities**: memoizee for caching, jsdom for web scraping

## Deployment Strategy

### Environment Variables
- `DATABASE_URL`: PostgreSQL connection string
- `OPENAI_API_KEY`: OpenAI API access key
- `STRIPE_SECRET_KEY`: Stripe secret key for server
- `VITE_STRIPE_PUBLIC_KEY`: Stripe publishable key for client
- `SESSION_SECRET`: Session encryption secret
- `REPL_ID`: Required for Replit Auth
- `ISSUER_URL`: OIDC issuer URL (defaults to Replit)

### Build Process
- **Development**: `npm run dev` - Runs both client and server in development
- **Production Build**: `npm run build` - Builds client with Vite, bundles server with esbuild
- **Database**: `npm run db:push` - Pushes schema changes to database

### Key Features
- **Freemium Model**: Free tier (5 summaries/month) vs Pro tier (unlimited)
- **Content Categorization**: AI automatically categorizes blog posts
- **Reading Time Estimation**: Calculates estimated reading time for original content
- **Export/Share**: Users can copy summaries or share blog URLs
- **Responsive Design**: Mobile-optimized UI with Tailwind CSS

The application prioritizes user experience with fast summarization, clean UI, and seamless subscription management while maintaining data security and scalability through modern web technologies.